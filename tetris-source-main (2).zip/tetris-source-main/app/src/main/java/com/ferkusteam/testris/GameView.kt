package com.ferkusteam.testris

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs

class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
    private val paint = Paint().apply {
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val gridPaint = Paint().apply {
        style = Paint.Style.STROKE
        color = Color.GRAY
        strokeWidth = 1f
    }

    private val blockSize: Float by lazy {
        resources.displayMetrics.widthPixels.toFloat() / (gridWidth + 4)
    }

    private val gridWidth = 10
    private val gridHeight = 20
    private var grid = Array(gridHeight) { BooleanArray(gridWidth) }
    private var currentPiece: Piece? = null
    private var nextPiece: Piece? = null
    private var score = 0
    private var level = 1
    private var paused = false
    private var onScoreChangedListener: ((Int, Int) -> Unit)? = null
    private var onGameOverListener: (() -> Unit)? = null

    private val pieces = listOf(
        Piece(listOf(0x0F00, 0x2222, 0x00F0, 0x4444), Color.CYAN),
        Piece(listOf(0x0660), Color.YELLOW),
        Piece(listOf(0x4460, 0x02E0, 0x0622, 0x0740), Color.MAGENTA),
        Piece(listOf(0x4620, 0x6C00, 0x4620, 0x6C00), Color.BLUE),
        Piece(listOf(0x2640, 0x0C60, 0x2640, 0x0C60), Color.RED),
        Piece(listOf(0x0360, 0x0C60, 0x0360, 0x0C60), Color.GREEN),
        Piece(listOf(0x0630, 0x0C30, 0x0630, 0x0C30), Color.RED)
    )

    fun setOnScoreChangedListener(listener: (Int, Int) -> Unit) {
        onScoreChangedListener = listener
    }

    fun setOnGameOverListener(listener: () -> Unit) {
        onGameOverListener = listener
    }

    fun initGame() {
        grid = Array(gridHeight) { BooleanArray(gridWidth) }
        score = 0
        level = 1
        paused = false
        spawnNewPiece()
        onScoreChangedListener?.invoke(score, level)
        invalidate()
    }

    fun togglePause() {
        paused = !paused
    }

    fun pauseGame() {
        paused = true
    }

    fun resumeGame() {
        paused = false
    }

    fun isPaused(): Boolean = paused

    fun moveLeft() {
        if (paused) return
        currentPiece?.let { piece ->
            if (canMove(piece, piece.x - 1, piece.y, piece.rotation)) {
                piece.x--
                invalidate()
            }
        }
    }

    fun moveRight() {
        if (paused) return
        currentPiece?.let { piece ->
            if (canMove(piece, piece.x + 1, piece.y, piece.rotation)) {
                piece.x++
                invalidate()
            }
        }
    }

    fun moveDown(): Boolean {
        if (paused) return false
        currentPiece?.let { piece ->
            if (canMove(piece, piece.x, piece.y + 1, piece.rotation)) {
                piece.y++
                invalidate()
                return true
            } else {
                lockPiece()
                val linesCleared = clearLines()
                if (linesCleared > 0) {
                    updateScore(linesCleared)
                }
                if (!spawnNewPiece()) {
                    onGameOverListener?.invoke()
                }
                return false
            }
        }
        return false
    }

    fun rotate() {
        if (paused) return
        currentPiece?.let { piece ->
            val newRotation = (piece.rotation + 1) % piece.shape.size
            if (canMove(piece, piece.x, piece.y, newRotation)) {
                piece.rotation = newRotation
                invalidate()
            }
        }
    }

    private fun spawnNewPiece(): Boolean {
        currentPiece = nextPiece ?: pieces.random().copy()
        nextPiece = pieces.random()
        currentPiece?.let {
            it.x = gridWidth / 2 - 2
            it.y = 0
            if (!canMove(it, it.x, it.y, it.rotation)) {
                return false
            }
        }
        invalidate()
        return true
    }

    private fun lockPiece() {
        currentPiece?.let { piece ->
            for (y in 0..3) {
                for (x in 0..3) {
                    if (piece.isBlock(x, y)) {
                        val gridY = piece.y + y
                        val gridX = piece.x + x
                        if (gridY in 0 until gridHeight && gridX in 0 until gridWidth) {
                            grid[gridY][gridX] = true
                        }
                    }
                }
            }
        }
    }

    private fun clearLines(): Int {
        var linesCleared = 0
        outer@ for (y in gridHeight - 1 downTo 0) {
            for (x in 0 until gridWidth) {
                if (!grid[y][x]) continue@outer
            }
            for (yy in y downTo 1) {
                System.arraycopy(grid[yy - 1], 0, grid[yy], 0, gridWidth)
            }
            grid[0] = BooleanArray(gridWidth)
            linesCleared++
        }
        if (linesCleared > 0) {
            invalidate()
        }
        return linesCleared
    }

    private fun updateScore(lines: Int) {
        val points = when (lines) {
            1 -> 100
            2 -> 300
            3 -> 500
            4 -> 800
            else -> 0
        } * level

        score += points
        level = (score / 2000) + 1
        onScoreChangedListener?.invoke(score, level)
    }

    private fun canMove(piece: Piece, newX: Int, newY: Int, newRotation: Int): Boolean {
        for (y in 0..3) {
            for (x in 0..3) {
                if (piece.isBlock(x, y, newRotation)) {
                    val xx = newX + x
                    val yy = newY + y
                    if (xx < 0 || xx >= gridWidth || yy >= gridHeight || (yy >= 0 && grid[yy][xx])) {
                        return false
                    }
                }
            }
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        for (y in 0 until gridHeight) {
            for (x in 0 until gridWidth) {
                if (grid[y][x]) {
                    paint.color = Color.GRAY
                    canvas.drawRect(
                        RectF(
                            x * blockSize,
                            y * blockSize,
                            (x + 1) * blockSize,
                            (y + 1) * blockSize
                        ), paint
                    )
                }
                canvas.drawRect(
                    RectF(
                        x * blockSize,
                        y * blockSize,
                        (x + 1) * blockSize,
                        (y + 1) * blockSize
                    ), gridPaint
                )
            }
        }

        currentPiece?.let { piece ->
            paint.color = piece.color
            for (y in 0..3) {
                for (x in 0..3) {
                    if (piece.isBlock(x, y)) {
                        val drawX = piece.x + x
                        val drawY = piece.y + y
                        if (drawY >= 0) {
                            canvas.drawRect(
                                RectF(
                                    drawX * blockSize,
                                    drawY * blockSize,
                                    (drawX + 1) * blockSize,
                                    (drawY + 1) * blockSize
                                ), paint
                            )
                        }
                    }
                }
            }
        }
    }

    data class Piece(
        val shape: List<Int>,
        val color: Int,
        var x: Int = 0,
        var y: Int = 0,
        var rotation: Int = 0
    ) {
        fun isBlock(x: Int, y: Int, rotation: Int = this.rotation): Boolean {
            return (shape[rotation] and (1 shl (15 - (y * 4 + x)))) != 0
        }

        fun copy(): Piece {
            return Piece(shape, color, x, y, rotation)
        }
    }
}