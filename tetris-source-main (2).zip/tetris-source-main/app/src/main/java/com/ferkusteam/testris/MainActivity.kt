package com.ferkusteam.testris

import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import androidx.appcompat.app.AppCompatActivity
import com.ferkusteam.testris.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var gameView: GameView
    private lateinit var handler: Handler
    private lateinit var runnable: Runnable
    private var gameSpeed = 500L
    private var isGameRunning = false
    private var x1 = 0f
    private var y1 = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        try {
            val pInfo = packageManager.getPackageInfo(packageName, 0)
            binding.versionText.text = getString(R.string.version, pInfo.versionName)
        } catch (e: PackageManager.NameNotFoundException) {
            binding.versionText.text = getString(R.string.version_default)
        }

        gameView = binding.gameView.apply {
            setOnScoreChangedListener { score, level ->
                binding.scoreText.text = getString(R.string.score, score)
                binding.levelText.text = getString(R.string.level, level)
            }

            setOnGameOverListener {
                handler.removeCallbacks(runnable)
                isGameRunning = false
            }
        }

        handler = Handler(Looper.getMainLooper())
        startGame()

        binding.root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    x1 = event.x
                    y1 = event.y
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val x2 = event.x
                    val y2 = event.y

                    val deltaX = x2 - x1
                    val deltaY = y2 - y1

                    if (Math.abs(deltaX) > Math.abs(deltaY)) {
                        // Горизонтальный свайп
                        if (deltaX > 0) gameView.moveRight() else gameView.moveLeft()
                    } else {
                        // Вертикальный свайп
                        if (deltaY > 0) gameView.moveDown() else gameView.rotate()
                    }
                    true
                }
                else -> false
            }
        }

        binding.pauseButton.setOnClickListener {
            if (isGameRunning) {
                gameView.togglePause()
                binding.pauseButton.setImageResource(
                    if (gameView.isPaused()) android.R.drawable.ic_media_play
                    else android.R.drawable.ic_media_pause
                )
            }
        }
    }

    private fun startGame() {
        gameView.initGame()
        isGameRunning = true
        runnable = object : Runnable {
            override fun run() {
                if (!gameView.isPaused()) {
                    gameView.moveDown()
                }
                handler.postDelayed(this, gameSpeed)
            }
        }
        handler.postDelayed(runnable, gameSpeed)
    }

    override fun onPause() {
        super.onPause()
        if (isGameRunning) {
            gameView.pauseGame()
            handler.removeCallbacks(runnable)
        }
    }

    override fun onResume() {
        super.onResume()
        if (isGameRunning && !gameView.isPaused()) {
            handler.postDelayed(runnable, gameSpeed)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(runnable)
    }
}